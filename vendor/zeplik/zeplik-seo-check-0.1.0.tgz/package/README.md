# @zeplik/seo-check

Component 5b of the Zeplik SEO engine. A library, a CLI and a GitHub Action that crawl a site's built
routes and **fail CI on any breach of the indexability contract** (operating manual 8.1 to 8.5), the
section 6 schema rules, the rendered-HTML rows of the section 7 G2 table, the AdSense rules in 15.1/15.2
and the manifest rules in 16.2. Railway's "Wait for CI" holds every deploy on it (16.4).

A URL is either fully indexable and worth indexing, or out of the index on purpose. Nothing sits in between.

## Usage

```sh
# Crawl a running production build (http://127.0.0.1:3000) as the production origin.
seo-check crawl --base http://127.0.0.1:3000 --origin https://optipix.art --manifest seo/manifest.json --ad-site --json report.json

seo-check manifest seo/manifest.json            # validate only (and diff against HEAD~1)
seo-check page https://optipix.art/compress-jpg --type tool
seo-check crawlers --base https://optipix.art --paths /,/compress-jpg
seo-check perf --base http://127.0.0.1:3000 --templates templates.json [--ad-site]
SEO_HUB_SECRET=... seo-check post-manifest --hub https://cms.zeplik.com --site optipix.art
```

`crawl` options: `--max-pages N` (default 1000), `--concurrency N` (8), `--allowlist seo/seo-check.allow.json`
(read automatically when present), `--publisher pub-XXXXXXXXXXXXXXXX` (ads.txt must list it),
`--redirects <file|url>` (a hub `RedirectsResponse`: gone URLs must answer 410, redirects must be one hop),
`--min-words N` (words of server-rendered `<main>`/`<article>` text, default 80), `--no-ad-placement`,
`--no-manifest`, `--no-git-diff`, `--site-role money|feeder|ad|entity|local` (when there is no manifest).

Output: human report grouped by rule (errors first, each rule with its manual section and fix hint),
`--json <file>` (or `--json -`) for the full machine report, and GitHub annotations plus a job summary
table when `GITHUB_ACTIONS` is set. Exit code 1 on any error, 0 with warnings only, 2 on usage errors.

### What a crawl does

1. Validates `seo/manifest.json` against the `@zeplik/core` `Manifest` schema and, with
   `git show HEAD~1:seo/manifest.json`, fails features that were deleted instead of retired.
2. Reads robots.txt, then every sitemap it declares (or `/sitemap.xml`, `/sitemap_index.xml`),
   following sitemap indexes. Sitemap URLs are production URLs; they are fetched on `--base`.
3. Crawls from the homepage, every sitemap URL, every live manifest path, then internal links (assets
   skipped). Each page is fetched without JavaScript, again as a mobile user agent (8.1-5), and the
   first 50 expected-indexable pages again with `?q=...&utm_source=...` (8.2-10).
4. Site-level checks: sitemap membership (exactly one), 3+ inbound internal links in the crawl graph,
   canonical targets, broken and redirecting links, retired features (301/308 one hop to `replacedBy`,
   or 410), an unknown URL (must 404, no ads on it), the other trailing-slash form, mixed slash forms,
   HSTS / http->https / www-twin when `--base` is the production origin, crawler access for every agent
   in `rules/crawlers.yaml`, ads.txt, and Playwright ad placement on one page per template (ad sites).

### Library

```ts
import { checkPage, crawlSite, checkCrawlerAccess, measureTemplates, postManifest } from "@zeplik/seo-check";

// Hub G5 (pre-publish) and G6 (day 1), manual 12:
const page = await checkPage("https://optipix.art/guides/compress-jpg", { origin: "https://optipix.art", expectIndexable: true, sitemapUrls });
// page.findings: { rule, severity: "error" | "warning", url, message, fix }[]

const site = await crawlSite({ base: "http://127.0.0.1:3000", origin: "https://optipix.art", manifestPath: "seo/manifest.json", adSite: true, maxPages: 5000, concurrency: 8 });

// seo-ingest weekly (8.3): status per crawler per path, robots.txt verdict per token, p1 flag.
const access = await checkCrawlerAccess("https://optipix.art", loadCrawlers(), { samplePaths: ["/", "/compress-jpg"] });

// Lab CWV per template (8.1 point 6): 390 px viewport, 4x CPU throttle, LCP + CLS from PerformanceObserver, TBT from long tasks.
const perf = await measureTemplates({ base, templates: [{ name: "tool", url: "/compress-jpg" }], budget: { lcp_ms: 2500, cls: 0.1, tbt_ms: 200 } });

// 16.4 step 3, HMAC-signed with core signBody (x-zeplik-signature / x-zeplik-timestamp).
await postManifest({ hubUrl, secret, site, repo, commit, ref, manifest, previous });
```

Also exported: `checkAdsTxt`, `checkAdPlacement`, `parseRobots`/`isAllowed`, `parseSitemap`, `extractFacts`,
`formatHuman`, `githubAnnotations`, `RULES`, `defaultBudget` and the report types (`PageReport`, `SiteReport`,
`CrawlerAccessResult`, `TemplatePerfResult`, `Finding`).

### Markup contract the checks read

| Selector | Meaning |
|---|---|
| `<main>` or `<article>` | main content; must hold `--min-words` words in server HTML (8.1 point 1) |
| `ins.adsbygoogle`, `[data-ad-slot]`, `[data-ad]` | an ad slot (seo-kit `AdSlot`) |
| `[data-tool-control]` | upload, convert, download controls: ads stay 150 px away (15.1 point 2) |
| `[data-tool]`, `[data-answer]` | the tool and the direct answer: no ad above either on mobile (15.1 point 3) |
| `[data-cta]` | the product CTA: before the first ad on feeder pages (15.1 point 5) |
| `[data-seo-ignore]` | excluded from the word count |

### Allowlist (`seo/seo-check.allow.json`)

Legacy exceptions, reviewed like rule changes (13.2). Listed paths turn specific errors into warnings;
entries ending in `*` match a prefix. See `examples/seo-check.allow.json`.

```json
{
  "legacySchema": ["/faq"],
  "reviews": [],
  "legacyUrls": ["/Old_Page"],
  "downgrade": [{ "rule": "8.1-3.links", "path": "/press", "reason": "why, and until when" }]
}
```

## Rules

Every finding names one of these rule ids. Severity is error unless noted.

| Rule | Manual | Check | Severity |
|---|---|---|---|
| `8.1-1` | 8.1 (1) | Indexable URL returns 200 | error |
| `8.1-1.ssr` | 8.1 (1) | Main content is in the server HTML | error |
| `8.1-2` | 8.1 (2) | Exactly one absolute, self-referencing canonical | error |
| `8.1-2.target` | 8.1 (2) | Canonical target is a live, indexable 200 URL | error |
| `8.1-3.sitemap` | 8.1 (3), 8.2 | Indexable URL is in exactly one sitemap | error |
| `8.1-3.links` | 8.1 (3) | Indexable URL has at least 3 internal inbound links | warning when the crawl was truncated by --max-pages |
| `8.1-4.noindex` | 8.1 (4) | Indexable URL carries no noindex | error |
| `8.1-4.robots` | 8.1 (4) | Indexable URL is not blocked in robots.txt | error |
| `8.1-5` | 8.1 (5) | Mobile matches desktop: same content and structured data | error |
| `8.1-6` | 8.1 (6), 8.1 CWV | Template within the Core Web Vitals lab budget | error |
| `8.2-1` | 8.2 Canonicals | No noindex combined with a cross-canonical | error |
| `8.2-2` | 8.2 Canonicals | With hreflang, the canonical stays in the same language | error |
| `8.2-3` | 8.2 Sitemaps | Sitemaps list only canonical, indexable, 200 URLs on the production host | error |
| `8.2-4` | 8.2 Sitemaps | lastmod is never in the future | error |
| `8.2-5` | 8.2 Sitemaps | lastmod is not stamped on every URL at build time | error when every lastmod is the crawl date; warning when 5+ are identical |
| `8.2-6` | 8.2 Deleted pages | Deleted pages answer 410 (or 301 to a true equivalent); no soft 404s | error |
| `8.2-7` | 8.2 Redirects | Redirects are one hop | error |
| `8.2-8` | 8.2 Redirects | Permanent moves use 301 or 308, not 302/307 | error on URLs expected to be indexable and on retired/hub redirects; warning on other internal links |
| `8.2-9` | 8.2 URLs | URL format: lowercase, hyphens, no dates, no IDs, short | warning for paths in legacyUrls |
| `8.2-10` | 8.2 Parameters | Parameter URLs (?q=, ?file=, utm_*) canonicalize to the clean URL | error |
| `8.2-11` | 8.2 Hosts | One host, HTTPS, HSTS | error |
| `8.2-12` | 8.2 Hosts | Consistent trailing slashes | warning when both forms answer 200 but canonicalize correctly |
| `8.2-13` | 8.2 Status codes | Internal links resolve to 200 without redirects | error for 4xx/5xx targets; warning for links to redirects |
| `8.3-1` | 8.3 | Allowed crawlers get 200 (P1 for Googlebot, Bingbot, OAI-SearchBot) | error for P1 crawlers (Googlebot, Bingbot, OAI-SearchBot); warning for the rest |
| `8.3-2` | 8.3 | robots.txt allows the house crawler list | error for P1 crawlers; warning for others, a missing robots.txt or a missing Sitemap: line |
| `8.5-1` | 8.5 | JSON-LD parses and uses schema.org | error |
| `8.5-2` | 8.5 | JSON-LD matches the visible page (headline/name equals H1 or title) | error |
| `8.5-3` | 8.5 | Homepage carries Organization and WebSite markup | warning only |
| `6-1` | 6 Structured data status | No FAQPage or HowTo markup on pages | warning for paths in legacySchema |
| `6-2` | 6 table, 8.5 | Schema matches the page type in the manifest | error |
| `GR-33` | 7 GR-33, 6 | No Review or AggregateRating markup without real reviews | error |
| `G2-h1` | 7 G2 (H1 count) | Exactly one H1 | error |
| `G2-title` | 7 G2 (title) | Title present, up to 60 characters | missing = error; over 60 characters = warning |
| `G2-meta` | 7 G2 (meta) | Meta description present, 140 to 160 characters | missing = error; outside 140-160 = warning |
| `G2-images` | 7 G2 (images) | Images have alt, width and height | error |
| `15.1-1` | 15.1 (1) | No ads on error, empty or thin pages | error |
| `15.1-2` | 15.1 (2) | Ads at least 150 px from upload, convert and download controls | error |
| `15.1-3` | 15.1 (3) | No ad above the tool or the answer on mobile (390 px) | error |
| `15.1-4` | 15.1 (4) | At most one ad per 600 px of mobile scroll, ad area below content area | error |
| `15.1-5` | 15.1 (5) | Feeder pages: product CTA before the first ad | error |
| `15.2-1` | 15.2 | Ad slots reserve their height | error |
| `15.2-2` | 15.2, 3 | ads.txt present and well-formed on ad sites; no AdSense on money sites | error on ad sites; warning when a money site serves ads.txt; error for ad slots on money sites |
| `16.2-1` | 16.2 | seo/manifest.json present and valid | warning when the manifest site differs from the origin host |
| `16.2-2` | 16.2, 16.4 | Every live feature path returns 200 and is in a sitemap | error |
| `16.2-3` | 16.2, 8.2, 8.6 | Retired features 301 to replacedBy in one hop, or answer 410 | error |
| `16.2-4` | 16.2 | Features are retired, never deleted from the manifest | error |
Performance budget: `rules/thresholds.yaml` `cwv` (LCP 2500 ms, CLS 0.1). The lab proxy for INP is
Total Blocking Time with the same 200 ms number (`thresholds.yaml` has no separate TBT key). Ad sites
are measured twice per template: ads disabled (ad network requests blocked) and ads enabled (each slot
is filled with a creative of its reserved height, or 250 px when it reserved nothing), so a slot that
does not reserve its height shows up as CLS.

## CI setup

### 1. Publish the package

`@zeplik/seo-check` and `@zeplik/core` publish to GitHub Packages (`publishConfig.registry`). The build
copies `rules/crawlers.yaml`, `rules/thresholds.yaml` and `rules/page-types.yaml` into the package, so
product repos need no copy of the brain repo.

```sh
pnpm -r build && pnpm --filter @zeplik/core publish && pnpm --filter @zeplik/seo-check publish
```

### 2. Add the caller workflow to the product repo

Copy one file from `examples/` to `.github/workflows/seo-check.yml` and set `origin` and `ad-site`:

| Example | Stack | Repos |
|---|---|---|
| `examples/nextjs16-npm.yml` | npm + Next 16 | seedance-platform (arteza.ai), zeplik, inrick, calcmyway, isthisascam |
| `examples/pnpm-monorepo-optipix.yml` | pnpm workspace, app in a sub-folder | Opti-Pix-Art (`artifacts/optipix`) |
| `examples/pnpm-monorepo-filter.yml` | pnpm monorepo with `--filter` | bgeraser (`@bgeraser/web`) |
| `examples/nextjs14-npm.yml` | npm + Next 14 | specpair, nishaaan-website |

The caller uses `product-zeplik/zeplik-seo-engine/.github/workflows/seo-check-reusable.yml@main`, which
checks out the repo (2 commits deep for the manifest diff), installs, builds, starts the app on `port`,
waits for it, then runs the composite action `.github/actions/seo-check`: install seo-check and
Chromium, `seo-check crawl`, `seo-check perf` (templates from `templates`, else one live path per
manifest page type plus `/`), upload the JSON reports as the `seo-check-report` artifact, fail the job
on any error, and on a push to the default branch post the manifest to the hub. A hub outage only warns:
it never blocks a deploy that passed the contract.

Inputs: `origin` (required), `install-command`, `build-command`, `start-command`, `port`, `ad-site`,
`manifest-path`, `node-version`, `package-manager` (npm or pnpm), `working-directory`, `build-env`
(KEY=VALUE lines of non-secret placeholders), `templates`, `max-pages`, `allowlist`, `publisher`, `site`,
`hub-url`, `seo-check-version`, `wait-timeout`, `timeout-minutes`.

Secrets: `NPM_TOKEN` (read:packages on npm.pkg.github.com, also used to install `@zeplik/seo-kit`),
`SEO_HUB_SECRET` (the hub's manifest webhook HMAC secret; optional, without it nothing is posted).

The engine repo must allow reuse: Settings, Actions, General, Access, "Accessible from repositories in
the 'product-zeplik' organization".

### 3. Turn on Railway "Wait for CI" for every service

For each Railway service that deploys a site (one per product repo; for monorepos, every service that
serves pages):

1. Railway dashboard, the project, the service, **Settings**, **Source**.
2. Confirm the service is connected to the GitHub repo and the production branch (`main`).
3. Turn on **Wait for CI**. Railway then waits for the GitHub check suites on each pushed commit
   (seo-check included) and skips the deploy when any of them fails; production keeps the previous
   version (16.4 point 2).
4. Push a commit and confirm the deployment shows "Waiting for CI" before it builds.

Wait for CI requires a GitHub Actions workflow in the repository and the updated Railway GitHub app
permissions accepted (Railway prompts for them; see docs.railway.com, Controlling GitHub Autodeploys,
Wait for CI). The workflow must run on `push` to the deploy branch (the examples do). Pull requests
get the same check without deploying. Keep the job name `seo-check` stable so branch protection rules
can require it too.

### 4. Run locally before committing (16.3)

```sh
npm run build && npx next start -p 3000 &
npx seo-check crawl --base http://127.0.0.1:3000 --origin https://<site> --ad-site
```

## Development

```sh
pnpm --filter @zeplik/core build
pnpm --filter @zeplik/seo-check typecheck
pnpm --filter @zeplik/seo-check test   # fixture sites on node:http, Playwright Chromium for ads and perf
pnpm --filter @zeplik/seo-check build
```

`test/fixtures/good-site.ts` is a fully compliant site that must produce zero errors and zero warnings;
`test/fixtures/bad-site.ts` has one route per rule and `EXPECTED` maps each rule to the route that must
fail it.
