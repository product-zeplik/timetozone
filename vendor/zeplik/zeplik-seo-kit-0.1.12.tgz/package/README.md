# @zeplik/seo-kit

The one SEO package every Zeplik product site imports (operating manual, component 5). It owns page heads,
canonicals, JSON-LD, the tool and article templates, CTA and ad slots, the hub client, sitemaps, robots,
the revalidate webhook, IndexNow, ads.txt and the redirect middleware. Product repos own the working tool;
the content hub owns the words (manual 16.1).

Supported: Next.js App Router 14.2 to 16 (React 18.2 to 19), Node 20+. Tested end to end on Next 14.2.35,
15.5.29 and 16.2.4.

## Install (GitHub Packages)

The package is private on GitHub Packages. In the product repo add `.npmrc`:

```
@zeplik:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

`GITHUB_TOKEN` needs `read:packages` (in CI and on Railway, set it as a build variable). Then:

```
npm install @zeplik/seo-kit        # also installs @zeplik/core
npx seo-kit init --site optipix.art --role feeder --name OptiPix
```

`seo-kit init` is idempotent. It never overwrites a file and never touches an existing robots.txt or
sitemap (16.3: no unasked robots changes). It creates:

| File | What |
|------|------|
| `seo.config.ts` (or `src/seo.config.ts`) | `defineSeoKit({...})`, the one config every helper takes |
| `app/api/seo/revalidate/route.ts` | hub webhook: HMAC check, revalidate, IndexNow |
| `app/[indexnowkey]/route.ts` | serves `/<key>.txt` (with a top-level `[locale]`, a rewrite to `app/api/seo/indexnow-key/[file]` instead) |
| `app/robots.ts` | `createRobots()` |
| `app/sitemap.ts` + `app/sitemap-index.xml/route.ts` | split sitemaps + index |
| `app/ads.txt/route.ts` | feeder and ad sites only; 404 until the publisher id is set |
| `seo/manifest.json` | skeleton with `$schema` |
| `CLAUDE.md` | appends the manual 16.3 block verbatim if missing |

## Environment variables

| Variable | Where | Purpose |
|----------|-------|---------|
| `ZEPLIK_REVALIDATE_SECRET` | server, required | HMAC secret shared with the hub. Without it the webhook answers 500 (fails closed). |
| `ZEPLIK_INDEXNOW_KEY` | server | 8 to 128 chars `[a-zA-Z0-9-]`. Served at `/<key>.txt`; pinged on publish, update, delete. Same key in Bing Webmaster Tools. |
| `ZEPLIK_HUB_URL` | server, optional | Defaults to `https://cms.zeplik.com`. |
| `NEXT_PUBLIC_ADSENSE_CLIENT` | build, ad sites only | `ca-pub-...`. Set only after AdSense approval (15.5). Money sites can never enable ads: `defineSeoKit` throws. |

The canonical origin is a literal in `seo.config.ts`, never an env var: canonicals must not change with the
deploy environment.

## Setup per site

```ts
// seo.config.ts
export const kit = defineSeoKit({
  site: "optipix.art",                 // sites/*.yaml domain
  origin: "https://optipix.art",       // the one host (8.2)
  hubUrl: process.env.ZEPLIK_HUB_URL || "https://cms.zeplik.com",
  role: "feeder",                      // money | feeder | ad | entity | local
  adsAllowed: !!process.env.NEXT_PUBLIC_ADSENSE_CLIENT,
  adsenseClient: process.env.NEXT_PUBLIC_ADSENSE_CLIENT || undefined,
  trailingSlash: false,                // same as next.config
  locales: ["en"], defaultLocale: "en",
  localePrefix: "as-needed",           // next-intl default: default locale unprefixed
  organization: { name: "OptiPix", sameAs: ["https://x.com/optipix"] }, // parent defaults to Zeplik, Inc.
  indexNowKey: process.env.ZEPLIK_INDEXNOW_KEY || undefined,
});
```

Root layout: Organization + WebSite markup on every page, the stylesheet, and the AdSense loader (renders
nothing on money sites):

```tsx
import "@zeplik/seo-kit/styles.css";
import { SiteJsonLd } from "@zeplik/seo-kit";
import { AdSenseScript } from "@zeplik/seo-kit/client";
// <head><AdSenseScript client={kit.adsenseClient} allowed={kit.adsAllowed} /></head>
// <body><SiteJsonLd kit={kit} />{children}</body>
```

Use Google's certified Privacy and messaging CMP for EEA/UK/CH consent (15.2); it is configured in AdSense
and served by the same loader.

### Tool page (16.1)

```tsx
// app/compress-jpg/page.tsx
import { ToolPage, fetchToolCopy, toolMetadata } from "@zeplik/seo-kit";
export const revalidate = 3600;
export async function generateMetadata() {
  const copy = await fetchToolCopy(kit, "jpg-compressor");          // manifest feature id
  return toolMetadata(kit, copy, { path: "/compress-jpg", title: "Compress JPG", description: "..." });
}
export default function Page() {
  return <ToolPage kit={kit} slug="jpg-compressor" adSlot="1234567890"><JpgCompressor /></ToolPage>;
}
```

Order: breadcrumbs, H1 + one-liner, the tool (above the fold), steps, example output, limits and privacy,
body, a visible FAQ block (never FAQPage markup), related tools, the CTA, then the ad slot (150px from the
tool's controls, after the CTA). If the hub has no copy or is down, the tool still renders: with the last
good copy, else `fallbackCopy`, else a minimal H1 and one-liner, and no ads. Call `trackToolUsed(id)` from `@zeplik/seo-kit/client` when the tool
produces a result.

### Hub content (guides, comparisons, ...)

```tsx
// app/guides/[slug]/page.tsx
import { createContentRoute } from "@zeplik/seo-kit/next";
const route = createContentRoute({ kit, basePath: "/guides", pageTypes: ["guide"], adSlot: "..." });
export const generateStaticParams = route.generateStaticParams;
export const generateMetadata = route.generateMetadata;
export const revalidate = 3600;   // must be a literal in the route file
export default route.Page;
```

Under `app/[locale]/...` pass `localeParam: "locale"`. `<ArticlePage>` renders the single H1, the byline
with author and reviewer, published and updated dates (updated is `dateModified`, shown only when it
differs), the ownership disclosure near the top (comparison, alternatives and best-of get a default one if
the body has no `data-disclosure`), the body, one CTA right after the `data-answer` block, ads only where
allowed and always after the CTA, related links, and the hub JSON-LD (FAQPage and HowTo stripped).

Failure behaviour: hub 404, wrong page type or a path that does not match the hub's `path` give
`notFound()`. A hub outage or a response that fails the core schema throws instead: Next keeps serving
the last good ISR page, which a `notFound()` would have replaced with a 404. During `next build`, hub
outages only shrink `generateStaticParams` and the sitemap, so publishing can never break a deploy.

### Hub copy inside a tool page that already exists (`<HubCopy>`)

```tsx
// in the existing tool template, where the explanatory text goes (a server component)
import { HubCopy } from "@zeplik/seo-kit";
<HubCopy kit={kit} slug="jpg-compressor" />                          {/* manifest feature id */}
<HubCopy kit={kit} slug="jpg-compressor" fallback={<BuiltInText />} /> {/* the page's own block until the hub has copy */}
```

`<HubCopy>` renders only the hub's explanatory sections for a feature: steps, example output, limits and
privacy note, body, a visible FAQ (never FAQPage markup) and related tools, inside one
`<div class="zk-hub-copy" data-hub-copy="<feature id>">`. It never renders an H1, the page head, breadcrumbs,
JSON-LD, a CTA or an ad: the page keeps its own. And it renders **nothing at all** (no wrapper, no comment, no
whitespace) when the hub has no published copy for the feature or cannot be reached, so adding the slot to a
live template changes zero bytes of any page until the owner approves copy for that URL. The sections are the
same component `<ToolPageView>` uses (`ToolCopySections`), so the markup is identical. Options: `locale`,
`sections` (a subset of `steps | example | limits | about | faq | related-tools`), `labels`, `copy` (already
fetched with `fetchHubCopy`). The fetch carries the tool's cache tag, so the revalidate webhook refreshes it;
on a page with no `revalidate` of its own the slot's fetch gives the page the hub client's hourly ISR.

### Status document (`/.well-known/zeplik-seo.json`)

```ts
// app/.well-known/zeplik-seo.json/route.ts
import { createSiteStatusHandler, crawlerHitsState } from "@zeplik/seo-kit/next";
import { guides } from "@/lib/seo/content-routes";   // the object createContentRoute() returned
import { controls } from "@/lib/seo/page-controls";  // the site's one pageControls() source
export const dynamic = "force-dynamic";              // leave this line out when next.config has cacheComponents: true
export const GET = createSiteStatusHandler({ kit, contentRoutes: [guides], toolCopy: ["tools"], pageControls: controls, crawlerHits: crawlerHitsState() });
```

The site says what it can receive from the hub, from the objects its pages really use: the kit and core
versions, its locales, every hub content route (`basePath`, `pageTypes`, `locales`), the page families whose
template carries a hub copy slot (`toolCopy`: the `families` ids of `sites/<site>.yaml`; `["*"]` for every tool
page), whether an IndexNow key is configured, and the page-control state (on or off, set version, count, a
short error word), and the crawler-hit hook's state (`crawlerHitsState()`: switch on, secret present, reporting;
booleans only). No secret is in it: no key, no hub URL, no environment value. The hub reads it daily,
derives an article's path from the mounted route (`<locale prefix><basePath>/<slug>`), and refuses to plan
or publish what the site does not render. `createContentRoute()` registers its route by itself; keep each
route object in one module that both the page file and the status route import, and list it in
`contentRoutes` so the bundler cannot drop it:

```ts
// lib/seo/content-routes.ts
export const guides = createContentRoute({ kit, basePath: "/guides", pageTypes: ["guide", "glossary"] });
// app/guides/[slug]/page.tsx
import { guides } from "@/lib/seo/content-routes";
export const generateStaticParams = guides.generateStaticParams;
export const generateMetadata = guides.generateMetadata;
export const revalidate = 3600;
export default guides.Page;
```

### Hub media: hero, pictures and og:image (since 0.1.9)

Hub articles can carry generated illustrations (a hero and up to two inline pictures, or a short silent loop) and the
site's own screenshots. The hub sends them only to a site whose status document says it shows them:

- `<ArticlePage>` renders the hero right after the answer (never above it), as `<picture>` with AVIF and WebP
  `srcset`, width and height, eager and high priority with a matching `<link rel="preload">`. Inline pictures arrive
  in `bodyHtml` already rendered by the hub (`<figure data-media>`, lazy, sized); loops are `muted playsinline
  preload="none"` with a poster and never autoplay. `hero={false}` leaves the hero out.
- `articleMetadata()` uses the hub's 1200x630 OG rendition for og:image and twitter:image (with width, height, alt).
- The Article JSON-LD from the hub already carries the ImageObject nodes of the same files.
- Say it in the status document: `createSiteStatusHandler({ ..., media: true })` once the hub host
  (`hub-production-b4aad4f9.up.railway.app`, or `cms.zeplik.com` when the hub is served there) is allowed in `img-src`
  and `media-src`, or the site has no CSP. Until then the hub sends the site no media at all.
- Optional, same origin: `mediaBase: "/hub-media"` in `defineSeoKit` and `app/hub-media/[...key]/route.ts` with
  `export const { GET } = createMediaProxyHandler(kit)` (from `@zeplik/seo-kit/next`). Every media URL in the body, the
  records, the JSON-LD and og:image then points at the site; the route forwards only content-hashed keys and keeps
  the one-year immutable cache. With `mediaBase` set, the status document says `media.rendered` by itself. (Not
  `/_media`: an App Router folder starting with `_` is private and never routed.)
- `next/image` is not needed (the files are already sized and compressed). If a template uses it for hub pictures,
  add the hub host to `images.remotePatterns` with `pathname: "/api/public/media/**"`.

### Section indexes, the cluster block and `<HubLink>` (since 0.1.10)

A hub section index (a route's base path, e.g. `/guides`) exists only while the hub says it is **listable**: an
owner-approved intro and at least 3 published pages (rules/thresholds.yaml `sections`). Before that it answers 404,
stays out of the sitemap and must not be linked from nav or footer, so a one-page section never fails seo-check 8.1-1.
`index: true` tells the hub (through the status document) that the site renders the index, so the hub counts it as
an inbound link once it is listable. The status document carries every field of the core route contract since
0.1.12; 0.1.10 and 0.1.11 dropped `index` on the way out, so the hub never saw it.

```tsx
// lib/seo/content-routes.ts
export const guides = createContentRoute({ kit, basePath: "/guides", pageTypes: ["guide"], index: true });
// app/guides/page.tsx
export const generateMetadata = guides.generateIndexMetadata;
export const revalidate = 3600;
export default guides.IndexPage;            // 404 until listable; then the intro and every article
// sitemap: staticRoutes: [...yourRoutes, ...(await guides.indexStaticRoutes())]
// nav/footer: {(await guides.section({ locale })).listable ? <a href="/guides">Guides</a> : null}
```

`<ArticlePage>` renders the hub's cluster block (the page's pillar and siblings, live pages only) above the related
links. In a product page, link a hub page that may not be published yet with `<HubLink>`: it renders the anchor as
plain text until the hub lists the page, then the link, so the site never links a 404 (seo-check 8.2-13) and the hub
counts it as an inbound link the moment it publishes:

```tsx
<p>To shrink it first, read <HubLink kit={kit} href="/guides/compress-png">how to compress a PNG</HubLink>.</p>
```

### Client JS: the server entry `@zeplik/seo-kit/server` (since 0.1.12)

Next puts every client module a server module can reach into the route's client JS, a dynamic `import()` as much
as a static one. The root entry and `@zeplik/seo-kit/next` reach the ad slot and the tracked CTA link (through
`<ToolPageView>`, `<CtaBlock>` and `<ArticlePage>`), so a page that imports `<HubCopy>`, a content route or the
section helpers from there carries about 1.2 kB gzip of seo-kit client JS even when it shows no ad and no tracked
CTA (measured on a Next 15.5 build: 1229 bytes on the page, 0 from the server entry).

`@zeplik/seo-kit/server` exports the same server API (`defineSeoKit`, metadata, `JsonLd`, `ArticlePage`,
`ToolPage`, `CtaBlock`, `HubCopy`, `HubLink`, `SectionIndex`, `Breadcrumbs`, `RelatedLinks`, `HeroImage`,
`createContentRoute` with `section()` / `IndexPage` / `indexStaticRoutes()` / `hasPage()`, `createSiteStatusHandler`,
the sitemaps, the revalidate handler and the hub client) and names no client module anywhere in its graph. A page
that imports only from it ships zero seo-kit client JS. Where a page does show an ad slot or a tracked CTA, the
site passes the components itself, in the page file:

```tsx
import { AdSlot, CtaLink } from "@zeplik/seo-kit/client";
// app/guides/[slug]/page.tsx (the route object from createContentRoute of @zeplik/seo-kit/server)
export default guides.pageWith({ AdSlot, CtaLink });          // or guides.Page: no ad slot, plain CTA links
<ToolPage kit={kit} slug="jpg-compressor" adSlot="123" clients={{ AdSlot, CtaLink }}>{tool}</ToolPage>
<CtaBlock kit={kit} cta={cta} clients={{ CtaLink }} />           // the server CtaBlock takes the kit
```

Without `clients`, the ad slot is left out (the log says so once) and CTAs are plain server links (crawlable,
`data-cta-target` kept, no PostHog `cta_click`; a site that does not track CTAs sets `ctaTracking: false` and gets
no warning). With them, the markup is byte for byte the root entry's. The root entry is unchanged.

### Withdrawn content (since 0.1.10)

The hub answers an article or tool copy it unpublished, retired or deleted with 410 (or 301 to its successor),
never a plain 404. The client drops its remembered copy on a 410 or 301, and on a signed `unpublish`, `delete` or
`redirect` webhook, so the page leaves the site within the revalidate window. Timeouts, 5xx, network errors and a
404 from anything that is not the hub keep serving the last good copy.

Since 0.1.12 a withdrawal clears every memory of the process, not only the copy itself: a proxy's `route.hasPage()`
answer for the article, the pages `<HubLink>` saw live (it would otherwise keep linking the page through an outage)
and the sections' last good answer (so `section()` and the index close instead of counting the withdrawn page).
`<HubCopy>` remembers only "no copy" answers, so a withdrawn copy is an empty slot from the 410 on, outage or not.
One case the kit cannot see: on a page rendered per request, Next's data cache keeps serving the last 200 for a hub
read and refreshes it in the background without storing a 410, so there the withdrawal reaches the page through
the signed webhook (which the hub retries until it is delivered) or the next deploy.

### Content routes under Cache Components (Next 16, `cacheComponents: true`)

Two differences from the snippets above. The route file has no `revalidate` export (Cache Components refuse it)
and carries `export const instant = false;`, so a slug published after the build renders on request instead of
failing the static-shell check. And a missing slug cannot be a 404 from the page: the static shell is flushed with
a 200 before `notFound()` runs. Decide it in `proxy.ts` with `route.hasPage(pathname)`, which asks the hub the
same question the page does, remembers the answer for five minutes (the revalidate webhook clears it when an
article changes) and answers `true` when the hub cannot be asked, so an outage never 404s a live article:

```ts
// proxy.ts
if (path.startsWith("/guides/") && !ownGuide(path) && !(await guides.hasPage(path))) {
  return NextResponse.rewrite(new URL("/_not-found", request.url), { status: 404 });
}
```

### Middleware (301, 410, host, slash)

```ts
// middleware.ts (Next 14/15) or proxy.ts with `export async function proxy` (Next 16)
import { seoMiddleware } from "@zeplik/seo-kit/middleware";
const seo = seoMiddleware({ kit });
export async function middleware(req: NextRequest) { return (await seo(req)) ?? NextResponse.next(); }
export const config = { matcher: ["/((?!_next/|api/|favicon.ico).*)"] };
```

Hub redirects become one-hop 301s (chains are resolved), gone paths answer 410, and the www/apex
counterpart host and the trailing slash are fixed in the same single 301. Set
`skipTrailingSlashRedirect: true` in next.config so Next's own 308 does not add a hop. Preview hosts pass
untouched. If the site already has middleware, call `seo(req)` first and fall through to it.

### Page controls and the site's own floor

```ts
// lib/seo/page-controls.ts: one source, shared by the middleware and every sitemap route
import { pageControls } from "@zeplik/seo-kit/next";
export const controls = pageControls({
  kit,
  protect: ["/checkout", "/account"],      // never controlled here, in any locale (on top of the core list)
  allowPrefixes: ["/fr"],                  // a section this site lets the hub retire whole (not counted)
  sitemapUrlCount: () => registry.count(), // what "10% of the site" is measured against
});
// middleware: seoMiddleware({ kit, pageControls: controls }) (then seo.decorate(req, res)); sitemap: await controls.filterRows(rows);
// hreflang: alternates: { languages: await controls.filterAlternates(languages) }
```

The hub's controls are restrict-only (410, one-hop 301, `X-Robots-Tag: noindex, follow`, out of the sitemap)
and off unless `ZEPLIK_PAGE_CONTROLS=on` (production service only). Since 0.1.6 the site does not take the
hub's word for it. Before a set is applied, the kit checks it against the site's own rules:

| The set ... | The site ... |
|---|---|
| touches the homepage, belongs to another site, or is not a control set | refuses it whole and keeps its last good set |
| would control more than `maxShare` (default 10%) of the sitemap, a prefix counting as 10 URLs and a `locales: "all"` control once per locale (`minAbsolute` 5 URLs always allowed; 25 when the sitemap size is unknown) | refuses it whole and keeps its last good set |
| has an entry on a protected path, a one-segment prefix (`/blog`) not named in `allowPrefixes`, a redirect off the site or to the homepage, or a malformed entry | drops that entry, applies the rest |

A refused set or dropped entries are reported on every response (`X-Zeplik-Controls: v=...;applied=n;dropped=n;refused=share`)
and in `controls.status()`; the engine's daily verifier turns a refusal into a P1 and dropped entries into a P2.
A hub outage, a hub 404 without the hub's JSON, or a 5xx never empties the set: the last good one stays (pass
`store` to keep it across restarts). A control with `locales: "all"` names a bare path and applies to every
locale copy; `filterRows` and `filterAlternates` remove those copies from sitemaps and hreflang too.

Tool pages keep working through a hub outage as well: `fetchToolCopy` serves the last good copy, and
`<ToolPage fallbackCopy={...}>` gives the page its built-in text when the hub has none (`data-copy` on the
article says which one rendered: `hub`, `built-in` or `fallback`). A hub error never turns an existing page into a 404.

### Crawler-hit reporting (since 0.1.7, off by default)

```ts
// lib/seo/crawler-hits.ts
import { crawlerHits } from "@zeplik/seo-kit/middleware";
export const hits = crawlerHits({ kit });

// middleware.ts
export async function middleware(req: NextRequest, event: NextFetchEvent) {
  const res = (await seo(req)) ?? NextResponse.next();
  hits.record(req, res, event); // the last line before every return
  return res;
}
```

Counts what the 8.3 crawlers and AI-assistant referrals really fetch at the origin and sends it to the hub
in small signed batches: agent, path without query string, status, verified flag (the client address is
inside the vendor's published ranges), hour, count. It does nothing unless `ZEPLIK_CRAWLER_HITS=on`
(production only) and `ZEPLIK_REVALIDATE_SECRET` is set. `record()` is synchronous and cannot throw; the
network work runs after the response; no address, user agent, cookie, query string or referrer URL leaves
the site. `hits.status()` reports its state; `crawlerHitsState()` says on or off from the environment
alone, for code outside the middleware (the status document).

### Robots and sitemaps

```ts
// app/robots.ts
export default createRobots({ kit, trainingCrawlers: "allow", privatePaths: ["/api/"], contentPaths });
// or, for a Content-Signal line (Next's Robots type cannot carry it), app/robots.txt/route.ts:
export const GET = createRobots({ kit, trainingCrawlers: "disallow", contentSignal: "search=yes, ai-train=no, use=reference" }).GET;
```

Search and live-fetch crawlers (Googlebot, Bingbot, OAI-SearchBot, ChatGPT-User, Claude-SearchBot,
Claude-User, PerplexityBot, Perplexity-User) are always allowed. `trainingCrawlers` follows the site
config's `training_crawlers`: `disallow` writes one `Disallow: /` group for GPTBot, ClaudeBot,
Google-Extended and CCBot. Every agent is named in exactly one group (RFC 9309). If Cloudflare prepends a
managed block, pass `omitTrainingTokens` for the agents it already names. Content paths, `/` and `/_next/`
can never be disallowed.

Sitemaps merge hub entries, live tool and feature paths from `seo/manifest.json`, and `staticRoutes`. They
are split by page type and locale (`/sitemap/guide-en.xml`), skip anything the hub lists as redirected or
gone, and carry `lastmod` only from data, never the build time. Pass `lastmod` on static routes only when
you know the date of the last significant change.

**Recommended: sitemaps at request time (`createSitemapRoute`, since 0.1.12).** A sitemap prerendered at build
lists no hub page (nothing reads the hub at build), so after every deploy the hub's pages are missing until ISR
regenerates it, up to an hour. `createSitemapRoute` gives dynamic route handlers that build each answer from the
hub when asked (the hub client's data cache and the webhook keep that cheap), with a short CDN cache:

```ts
// lib/seo/sitemaps.ts
export const sitemaps = createSitemapRoute({
  kit, manifest,
  staticRoutes: async () => [...ownRoutes, ...(await guides.indexStaticRoutes())],   // asked per request
  filter: (rows) => controls.filterRows(rows),                                        // page controls: the last step
});
// app/sitemap-index.xml/route.ts  (keep the URLs robots.txt and Search Console already know)
export const dynamic = "force-dynamic";   // leave out under cacheComponents
export const GET = sitemaps.index;
// app/sitemap/[id]/route.ts       (/sitemap/guide-en.xml, as createSitemap served them; remove app/sitemap.ts)
export const dynamic = "force-dynamic";
export const GET = sitemaps.file;
// a small site with one file, app/sitemap.xml/route.ts: export const GET = sitemaps.all;
```

Every answer carries `Cache-Control: public, max-age=0, s-maxage=300, stale-while-revalidate=3600` and
`X-Zeplik-Sitemap: live`. A hub failure serves this process's last good rows (`last-good`); with none (a fresh
process and the hub down) the answer is a 503 with `Retry-After` and `no-store`, which crawlers retry, never a
sitemap without the hub's pages. The hub is never called during `next build`: a route prerendered anyway (the
`dynamic` line missing on Next 14/15) lists the manifest and static routes only, says `no-store` and `build`, and
logs the fix. `createSitemap` (the metadata route) keeps working as before.

Section indexes (`route.IndexPage`, `route.generateIndexMetadata`) are not built at `next build` either since
0.1.12: they mark themselves request-time, so a hub outage can no longer fail a deploy and an index never freezes
the hub's build-time answer. Their hub reads stay in the data cache under the sitemap tag.

## Integration steps for an existing site (17.6 prompt 7)

1. Install as above, run `npx seo-kit init`, set the env vars on Railway.
2. Move every page head onto `buildMetadata()` / `toolMetadata()` / `articleMetadata()` and every schema
   block onto `<JsonLd>` or `siteJsonLd()`. Delete hand-written meta tags and JSON-LD.
3. Wrap each live tool in `<ToolPage slug=...>` and add it to `seo/manifest.json` (id, path, type, status).
4. Mount hub content with `createContentRoute`, add `seoMiddleware`, and replace the old robots and
   sitemap routes with `createRobots` / `createSitemap` + `createSitemapIndex`. Keep any URL that has
   impressions exactly as it is; if one must change, add the 301 in the hub.
5. Ad sites: `<AdSlot>` only through the templates, ads.txt from the publisher id, Google's CMP.
6. Add the seo-check GitHub Action and turn on Railway's Wait for CI.
7. Verify: `curl` a tool page and an article and check the H1, canonical and JSON-LD in the server HTML;
   check `/robots.txt`, `/sitemap-index.xml`, `/<key>.txt`; send a signed test payload to
   `/api/seo/revalidate`.

## Entry points

| Import | Contents |
|--------|----------|
| `@zeplik/seo-kit` | `defineSeoKit`, `canonicalUrl`, `buildMetadata`, `articleMetadata`, `toolMetadata`, `JsonLd`, `SiteJsonLd`, `ArticlePage`, `ToolPage`, `CtaBlock`, `Breadcrumbs`, `RelatedLinks`, `CRAWLERS`, `CLAUDE_MD_BLOCK` |
| `@zeplik/seo-kit/server` | the server API without any client module: `ArticlePage`, `ToolPage`, `CtaBlock` (with `clients`), `HubCopy`, `HubLink`, `SectionIndex`, metadata, `JsonLd`, `createContentRoute` (+ `pageWith`), `createSiteStatusHandler`, `createSitemapRoute`, `createSitemap`, `createRevalidateHandler`, `createHubClient` |
| `@zeplik/seo-kit/client` | `AdSlot`, `AdSenseScript`, `CtaLink`, `trackCta`, `trackToolUsed`, `trackSignup` |
| `@zeplik/seo-kit/hub` | `createHubClient` (getArticle, getToolCopy, getSitemapEntries, getRedirects, getRelated), `HubError`, `HUB_TAGS` |
| `@zeplik/seo-kit/next` | `createRevalidateHandler`, `createIndexNowKeyHandler`, `createAdsTxtHandler`, `createSitemap`, `createSitemapIndex`, `createSitemapRoute`, `createRobots`, `createContentRoute`, `seoMiddleware` |
| `@zeplik/seo-kit/middleware` | `seoMiddleware`, `pageControls`, `crawlerHits` (lean edge bundle) |
| `@zeplik/seo-kit/jsonld` | the core JSON-LD builders |
| `@zeplik/seo-kit/styles.css` | base styles for the templates and the data-* content markup |
| `@zeplik/seo-kit/manifest.schema.json` | JSON Schema for `seo/manifest.json` |

Cache tags used by the hub client and invalidated by the webhook: `zeplik:article:<slug>`,
`zeplik:tool:<featureId>`, `zeplik:sitemap`, `zeplik:redirects`, `zeplik:related`.

## Development

```
pnpm --filter @zeplik/seo-kit typecheck
pnpm --filter @zeplik/seo-kit test
pnpm --filter @zeplik/seo-kit build
```
