# @zeplik/seo-kit

The one SEO package every Zeplik product site imports (operating manual, component 5). It owns page heads,
canonicals, JSON-LD, the tool and article templates, CTA and ad slots, the hub client, sitemaps, robots,
the revalidate webhook, IndexNow, ads.txt and the redirect middleware. Product repos own the working tool;
the content hub owns the words (manual 16.1).

Supported: Next.js App Router 14.2 to 16 (React 18.2 to 19), Node 20+. Tested end to end on Next 14.2.35,
15.5.29 and 16.2.4.

## Install (GitHub Packages)

The package is private on GitHub Packages. In the product repo add `.npmrc`:

```
@zeplik:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

`GITHUB_TOKEN` needs `read:packages` (in CI and on Railway, set it as a build variable). Then:

```
npm install @zeplik/seo-kit        # also installs @zeplik/core
npx seo-kit init --site optipix.art --role feeder --name OptiPix
```

`seo-kit init` is idempotent. It never overwrites a file and never touches an existing robots.txt or
sitemap (16.3: no unasked robots changes). It creates:

| File | What |
|------|------|
| `seo.config.ts` (or `src/seo.config.ts`) | `defineSeoKit({...})`, the one config every helper takes |
| `app/api/seo/revalidate/route.ts` | hub webhook: HMAC check, revalidate, IndexNow |
| `app/[indexnowkey]/route.ts` | serves `/<key>.txt` (with a top-level `[locale]`, a rewrite to `app/api/seo/indexnow-key/[file]` instead) |
| `app/robots.ts` | `createRobots()` |
| `app/sitemap.ts` + `app/sitemap-index.xml/route.ts` | split sitemaps + index |
| `app/ads.txt/route.ts` | feeder and ad sites only; 404 until the publisher id is set |
| `seo/manifest.json` | skeleton with `$schema` |
| `CLAUDE.md` | appends the manual 16.3 block verbatim if missing |

## Environment variables

| Variable | Where | Purpose |
|----------|-------|---------|
| `ZEPLIK_REVALIDATE_SECRET` | server, required | HMAC secret shared with the hub. Without it the webhook answers 500 (fails closed). |
| `ZEPLIK_INDEXNOW_KEY` | server | 8 to 128 chars `[a-zA-Z0-9-]`. Served at `/<key>.txt`; pinged on publish, update, delete. Same key in Bing Webmaster Tools. |
| `ZEPLIK_HUB_URL` | server, optional | Defaults to `https://cms.zeplik.com`. |
| `NEXT_PUBLIC_ADSENSE_CLIENT` | build, ad sites only | `ca-pub-...`. Set only after AdSense approval (15.5). Money sites can never enable ads: `defineSeoKit` throws. |

The canonical origin is a literal in `seo.config.ts`, never an env var: canonicals must not change with the
deploy environment.

## Setup per site

```ts
// seo.config.ts
export const kit = defineSeoKit({
  site: "optipix.art",                 // sites/*.yaml domain
  origin: "https://optipix.art",       // the one host (8.2)
  hubUrl: process.env.ZEPLIK_HUB_URL || "https://cms.zeplik.com",
  role: "feeder",                      // money | feeder | ad | entity | local
  adsAllowed: !!process.env.NEXT_PUBLIC_ADSENSE_CLIENT,
  adsenseClient: process.env.NEXT_PUBLIC_ADSENSE_CLIENT || undefined,
  trailingSlash: false,                // same as next.config
  locales: ["en"], defaultLocale: "en",
  localePrefix: "as-needed",           // next-intl default: default locale unprefixed
  organization: { name: "OptiPix", sameAs: ["https://x.com/optipix"] }, // parent defaults to Zeplik, Inc.
  indexNowKey: process.env.ZEPLIK_INDEXNOW_KEY || undefined,
});
```

Root layout: Organization + WebSite markup on every page, the stylesheet, and the AdSense loader (renders
nothing on money sites):

```tsx
import "@zeplik/seo-kit/styles.css";
import { SiteJsonLd } from "@zeplik/seo-kit";
import { AdSenseScript } from "@zeplik/seo-kit/client";
// <head><AdSenseScript client={kit.adsenseClient} allowed={kit.adsAllowed} /></head>
// <body><SiteJsonLd kit={kit} />{children}</body>
```

Use Google's certified Privacy and messaging CMP for EEA/UK/CH consent (15.2); it is configured in AdSense
and served by the same loader.

### Tool page (16.1)

```tsx
// app/compress-jpg/page.tsx
import { ToolPage, fetchToolCopy, toolMetadata } from "@zeplik/seo-kit";
export const revalidate = 3600;
export async function generateMetadata() {
  const copy = await fetchToolCopy(kit, "jpg-compressor");          // manifest feature id
  return toolMetadata(kit, copy, { path: "/compress-jpg", title: "Compress JPG", description: "..." });
}
export default function Page() {
  return <ToolPage kit={kit} slug="jpg-compressor" adSlot="1234567890"><JpgCompressor /></ToolPage>;
}
```

Order: breadcrumbs, H1 + one-liner, the tool (above the fold), steps, example output, limits and privacy,
body, a visible FAQ block (never FAQPage markup), related tools, the CTA, then the ad slot (150px from the
tool's controls, after the CTA). If the hub has no copy or is down, the tool still renders with a minimal
H1 and one-liner and no ads. Call `trackToolUsed(id)` from `@zeplik/seo-kit/client` when the tool
produces a result.

### Hub content (guides, comparisons, ...)

```tsx
// app/guides/[slug]/page.tsx
import { createContentRoute } from "@zeplik/seo-kit/next";
const route = createContentRoute({ kit, basePath: "/guides", pageTypes: ["guide"], adSlot: "..." });
export const generateStaticParams = route.generateStaticParams;
export const generateMetadata = route.generateMetadata;
export const revalidate = 3600;   // must be a literal in the route file
export default route.Page;
```

Under `app/[locale]/...` pass `localeParam: "locale"`. `<ArticlePage>` renders the single H1, the byline
with author and reviewer, published and updated dates (updated is `dateModified`, shown only when it
differs), the ownership disclosure near the top (comparison, alternatives and best-of get a default one if
the body has no `data-disclosure`), the body, one CTA right after the `data-answer` block, ads only where
allowed and always after the CTA, related links, and the hub JSON-LD (FAQPage and HowTo stripped).

Failure behaviour: hub 404, wrong page type or a path that does not match the hub's `path` give
`notFound()`. A hub outage or a response that fails the core schema throws instead: Next keeps serving
the last good ISR page, which a `notFound()` would have replaced with a 404. During `next build`, hub
outages only shrink `generateStaticParams` and the sitemap, so publishing can never break a deploy.

### Middleware (301, 410, host, slash)

```ts
// middleware.ts (Next 14/15) or proxy.ts with `export async function proxy` (Next 16)
import { seoMiddleware } from "@zeplik/seo-kit/middleware";
const seo = seoMiddleware({ kit });
export async function middleware(req: NextRequest) { return (await seo(req)) ?? NextResponse.next(); }
export const config = { matcher: ["/((?!_next/|api/|favicon.ico).*)"] };
```

Hub redirects become one-hop 301s (chains are resolved), gone paths answer 410, and the www/apex
counterpart host and the trailing slash are fixed in the same single 301. Set
`skipTrailingSlashRedirect: true` in next.config so Next's own 308 does not add a hop. Preview hosts pass
untouched. If the site already has middleware, call `seo(req)` first and fall through to it.

### Robots and sitemaps

```ts
// app/robots.ts
export default createRobots({ kit, trainingCrawlers: "allow", privatePaths: ["/api/"], contentPaths });
// or, for a Content-Signal line (Next's Robots type cannot carry it), app/robots.txt/route.ts:
export const GET = createRobots({ kit, trainingCrawlers: "disallow", contentSignal: "search=yes, ai-train=no, use=reference" }).GET;
```

Search and live-fetch crawlers (Googlebot, Bingbot, OAI-SearchBot, ChatGPT-User, Claude-SearchBot,
Claude-User, PerplexityBot, Perplexity-User) are always allowed. `trainingCrawlers` follows the site
config's `training_crawlers`: `disallow` writes one `Disallow: /` group for GPTBot, ClaudeBot,
Google-Extended and CCBot. Every agent is named in exactly one group (RFC 9309). If Cloudflare prepends a
managed block, pass `omitTrainingTokens` for the agents it already names. Content paths, `/` and `/_next/`
can never be disallowed.

Sitemaps merge hub entries, live tool and feature paths from `seo/manifest.json`, and `staticRoutes`. They
are split by page type and locale (`/sitemap/guide-en.xml`), skip anything the hub lists as redirected or
gone, and carry `lastmod` only from data, never the build time. Pass `lastmod` on static routes only when
you know the date of the last significant change.

## Integration steps for an existing site (17.6 prompt 7)

1. Install as above, run `npx seo-kit init`, set the env vars on Railway.
2. Move every page head onto `buildMetadata()` / `toolMetadata()` / `articleMetadata()` and every schema
   block onto `<JsonLd>` or `siteJsonLd()`. Delete hand-written meta tags and JSON-LD.
3. Wrap each live tool in `<ToolPage slug=...>` and add it to `seo/manifest.json` (id, path, type, status).
4. Mount hub content with `createContentRoute`, add `seoMiddleware`, and replace the old robots and
   sitemap routes with `createRobots` / `createSitemap` + `createSitemapIndex`. Keep any URL that has
   impressions exactly as it is; if one must change, add the 301 in the hub.
5. Ad sites: `<AdSlot>` only through the templates, ads.txt from the publisher id, Google's CMP.
6. Add the seo-check GitHub Action and turn on Railway's Wait for CI.
7. Verify: `curl` a tool page and an article and check the H1, canonical and JSON-LD in the server HTML;
   check `/robots.txt`, `/sitemap-index.xml`, `/<key>.txt`; send a signed test payload to
   `/api/seo/revalidate`.

## Entry points

| Import | Contents |
|--------|----------|
| `@zeplik/seo-kit` | `defineSeoKit`, `canonicalUrl`, `buildMetadata`, `articleMetadata`, `toolMetadata`, `JsonLd`, `SiteJsonLd`, `ArticlePage`, `ToolPage`, `CtaBlock`, `Breadcrumbs`, `RelatedLinks`, `CRAWLERS`, `CLAUDE_MD_BLOCK` |
| `@zeplik/seo-kit/client` | `AdSlot`, `AdSenseScript`, `CtaLink`, `trackCta`, `trackToolUsed`, `trackSignup` |
| `@zeplik/seo-kit/hub` | `createHubClient` (getArticle, getToolCopy, getSitemapEntries, getRedirects, getRelated), `HubError`, `HUB_TAGS` |
| `@zeplik/seo-kit/next` | `createRevalidateHandler`, `createIndexNowKeyHandler`, `createAdsTxtHandler`, `createSitemap`, `createSitemapIndex`, `createRobots`, `createContentRoute`, `seoMiddleware` |
| `@zeplik/seo-kit/middleware` | `seoMiddleware` alone (lean edge bundle) |
| `@zeplik/seo-kit/jsonld` | the core JSON-LD builders |
| `@zeplik/seo-kit/styles.css` | base styles for the templates and the data-* content markup |
| `@zeplik/seo-kit/manifest.schema.json` | JSON Schema for `seo/manifest.json` |

Cache tags used by the hub client and invalidated by the webhook: `zeplik:article:<slug>`,
`zeplik:tool:<featureId>`, `zeplik:sitemap`, `zeplik:redirects`, `zeplik:related`.

## Development

```
pnpm --filter @zeplik/seo-kit typecheck
pnpm --filter @zeplik/seo-kit test
pnpm --filter @zeplik/seo-kit build
```
